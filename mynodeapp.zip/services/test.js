var mongo = require("mongoose");

var Schema = mongo.Schema;
var lecturedb = new Schema({
    lect_id: { type: String },
    lect_name: { type: String },
    lect_address: { type: String },
    lect_department: { type: String }
  }, { versionKey: false });


  var studentdb = new Schema({
    stud_id: { type: String },
    stud_name: { type: String },
    stud_address: { type: String },
    stud_department: { type: String },
    stud_coursefees: { type: String },
    date: { type: Date }
  }, { versionKey: false });





var model = mongo.model('lecturedb', lecturedb, 'lecturedb');
var model1 = mongo.model('studentdb', studentdb, 'studentdb');

module.exports = function (app, express) {
  console.log("welcome to empService");
  var api = express.Router();



  api.post("/SaveUser", function (req, res) {
    var mod = new model(req.body);
    console.log('We are in server');
   

    mod.save(function (err, data) {
      if (err) {
        res.send(err);
      }
      else {
        res.send(JSON.stringify(req.body));
      }
    });
    })



  api.post("/getUserById", function (req, res) {
    console.log(req.body);
    model.findOne({ _id: mongo.Types.ObjectId(req.body.id) },
        function (err, data) {
            if (err) {
                res.send(err);
            }
            else {
                res.send(data);
            }
        });
})


api.post("/editUserById",function(req,res){
  debugger;
 console.log('In server editUserById');
 console.log(req.body); 
 console.log(req.body.id);     
  model.update({ _id:req.body.id},
       {$set: 
          {
               "name" :req.body.name,
          }},  
 function(err,data) {  
 if (err) {  
 res.send(err);         
 }  
 else{     
        
        res.send(data);  
   }  
});   
})


  return api;
}

